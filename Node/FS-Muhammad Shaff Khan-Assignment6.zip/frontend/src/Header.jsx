const Header = () => {
  return (
    <>
    <h1>Welcome to the Header Component</h1>
    </>
  )
}

export default Header