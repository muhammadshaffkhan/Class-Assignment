import Menubar from "./Menubar"
import Slides from "./Slide"
import Hero from "./Hero"
import Features from "./Features"
import AboutPreview from "./AboutPreview"
import ContactCTA from "./ContactCTA"
import Footer from "./Footer"

const Home = () => {
  return (
    <>
      <Menubar />
      <Slides />
      <Hero />
      <Features />
      <AboutPreview />
      <ContactCTA />
      <Footer />
    </>
  )
}

export default Home